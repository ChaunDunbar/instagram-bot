from instapy import InstaPy

session = InstaPy(username="takeonblocks", password="Password12345!")
session.login()

#following section
session.set_do_follow(True, percentage=50, times=1)


#comment section
session.set_do_comment(True, percentage=50)
session.set_comments([u'Intrested in Crypto Passive Income? Take a look at our YouTube channel and stay up to date with the latest crypto projects to make you passive income! @{}!'])

#like section
session.like_by_tags(['crypto', 'defi', 'passiveincome', 'luxurylifestyle', 'money'], amount=500)
session.set_dont_like(["naked", "nsfw", "sex"])


session.end()



